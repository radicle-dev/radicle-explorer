# Broken Mermaid

This diagram has invalid syntax and should fall back to a regular code block:

```mermaid
this is not -->-->-->-> valid mermaid
    ??? @@@
```
