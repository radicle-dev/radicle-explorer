# Broken Mermaid

This diagram has invalid syntax and shows a warning instead:

```mermaid
this is not -->-->-->-> valid mermaid
    ??? @@@
```

A subsequent valid diagram still renders, proving one bad block doesn't
break the rest of the document:

```mermaid
flowchart LR
    X --> Y
```
