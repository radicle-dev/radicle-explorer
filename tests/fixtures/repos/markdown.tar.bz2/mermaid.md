# Mermaid

A flowchart rendered with [Mermaid](https://mermaid.js.org/):

```mermaid
flowchart LR
    A[Start] --> B{Decision}
    B -->|Yes| C[Do this]
    B -->|No| D[Do that]
```

A second diagram in the same document:

```mermaid
sequenceDiagram
    Alice->>Bob: Hello
    Bob-->>Alice: Hi
```
