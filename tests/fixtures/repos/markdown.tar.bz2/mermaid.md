# Mermaid

A flowchart rendered with [Mermaid](https://mermaid.js.org/):

```mermaid
flowchart LR
    A[Start] --> B{Decision}
    B -->|Yes| C[Do this]
    B -->|No| D[Do that]
```
