This is intended as a quick reference and showcase. For more complete info, see [GitHubs Reference](https://docs.github.com/en/get-started/writing-on-github/working-with-advanced-formatting/writing-mathematical-expressions)

This sentence uses `$` delimiters to show math inline: $\sqrt{3x-1}+(1+x)^2$

**The Cauchy-Schwarz Inequality**

$$\left( \sum_{k=1}^n a_k b_k \right)^2 \leq \left( \sum_{k=1}^n a_k^2 \right) \left( \sum_{k=1}^n b_k^2 \right)$$

Within a math expression, add a \ symbol before the explicit $.  
This expression uses `\$` to display a dollar sign: $\sqrt{\$4}$

Outside a math expression, but on the same line, use a \ before the explicit $.  
To split \$100 in half, we calculate $100/2$
